require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

const createFinalAdmin = async () => {
    try {
        console.log('🔗 Connecting to database...');
        await mongoose.connect(process.env.MONGODB_URI);
        
        // Try different unique emails until one works
        const adminEmails = [
            'master.admin@system.com',
            'root.administrator@platform.org', 
            'super.manager@network.io',
            'chief.operator@web.app',
            'head.supervisor@api.dev'
        ];

        let createdAdmin = null;

        for (const email of adminEmails) {
            const existingAdmin = await User.findOne({ email });
            if (!existingAdmin) {
                createdAdmin = await User.create({
                    name: 'Master Administrator',
                    email: email,
                    password: 'master123',
                    phone_number: '+639555555555',
                    role: 'admin'
                });
                console.log(`✅ Admin created: ${email}`);
                break;
            } else {
                console.log(`ℹ️ ${email} already exists`);
            }
        }

        if (createdAdmin) {
            console.log('🎉 SUCCESS! Use these credentials:');
            console.log(`📧 Email: ${createdAdmin.email}`);
            console.log(`🔑 Password: master123`);
        } else {
            console.log('❌ All admin emails already exist. Using existing ones.');
            const existingAdmins = await User.find({ role: 'admin' });
            console.log('Existing admins:');
            existingAdmins.forEach(admin => {
                console.log(`- ${admin.email} (Password: try "admin123" or "password123")`);
            });
        }
        
        await mongoose.connection.close();
    } catch (error) {
        console.log('❌ Error:', error.message);
    }
};

createFinalAdmin();