require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

async function simpleAdmin() {
    console.log('Trying to create admin user...');
    
    try {
        // Connect with shorter timeout
        await mongoose.connect(process.env.MONGODB_URI, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });
        
        console.log('✅ Connected to MongoDB!');
        
        // Check if admin exists
        const admin = await User.findOne({ email: 'admin@example.com' });
        if (admin) {
            console.log('Admin already exists:', admin.email);
        } else {
            const newAdmin = await User.create({
                name: 'Admin User',
                email: 'admin@example.com',
                password: 'admin123',
                phone_number: '+1234567890',
                role: 'admin'
            });
            console.log('✅ Admin created:', newAdmin.email);
        }
        
        await mongoose.connection.close();
        console.log('Done!');
        
    } catch (error) {
        console.log('❌ Error:', error.message);
        console.log('But your API will still work for regular users!');
    }
}

simpleAdmin();