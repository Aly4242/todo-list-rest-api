const express = require('express');
const { getAllTodos, deleteAnyTodo, getAllUsers, deleteAnyUser } = require('../controllers/adminController');
const { protect } = require('../middleware/auth');
const { admin } = require('../middleware/admin');
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Admin
 *   description: Administrator management endpoints
 */

/**
 * @swagger
 * /admin/todos:
 *   get:
 *     summary: Get all todos from all users (Admin only)
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved all todos
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 count:
 *                   type: integer
 *                   example: 5
 *                 todos:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: "650c4d5e6f7a8b9c0d1e2f3a"
 *                       title:
 *                         type: string
 *                         example: "Complete project"
 *                       description:
 *                         type: string
 *                         example: "Finish the API documentation"
 *                       completed:
 *                         type: boolean
 *                         example: false
 *                       user:
 *                         type: object
 *                         properties:
 *                           _id:
 *                             type: string
 *                           name:
 *                             type: string
 *                           email:
 *                             type: string
 *       403:
 *         description: Admin access required
 *       500:
 *         description: Server error
 */
router.get('/todos', getAllTodos);

/**
 * @swagger
 * /admin/todos/{id}:
 *   delete:
 *     summary: Delete any todo item (Admin only)
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Todo ID to delete
 *         example: "650c4d5e6f7a8b9c0d1e2f3a"
 *     responses:
 *       200:
 *         description: Todo deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Todo deleted successfully by admin"
 *       403:
 *         description: Admin access required
 *       404:
 *         description: Todo not found
 *       500:
 *         description: Server error
 */
router.delete('/todos/:id', deleteAnyTodo);

/**
 * @swagger
 * /admin/users:
 *   get:
 *     summary: Get all users in the system (Admin only)
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved all users
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 count:
 *                   type: integer
 *                   example: 3
 *                 users:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: "691492acf7a474604e3ae3c3"
 *                       name:
 *                         type: string
 *                         example: "John Doe"
 *                       email:
 *                         type: string
 *                         example: "john@example.com"
 *                       phone_number:
 *                         type: string
 *                         example: "+1234567890"
 *                       role:
 *                         type: string
 *                         example: "user"
 *       403:
 *         description: Admin access required
 *       500:
 *         description: Server error
 */
router.get('/users', getAllUsers);

/**
 * @swagger
 * /admin/users/{id}:
 *   delete:
 *     summary: Delete any user account (Admin only)
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: User ID to delete
 *         example: "691492acf7a474604e3ae3c3"
 *     responses:
 *       200:
 *         description: User deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "User and their todos deleted successfully"
 *       400:
 *         description: Cannot delete own account
 *       403:
 *         description: Admin access required
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.delete('/users/:id', deleteAnyUser);

module.exports = router;