# Secure & Documented Todo List REST API

A secure, scalable RESTful API for a multi-user Todo List application with JWT authentication, role-based authorization, and comprehensive Swagger documentation.

## 🚀 Features

- **User Authentication** - JWT-based secure login/register
- **Role-Based Access** - User & Admin roles with different permissions
- **Todo Management** - Full CRUD operations for todo items
- **Admin Dashboard** - View/delete all users and todos
- **API Documentation** - Interactive Swagger UI
- **MongoDB Database** - Cloud database integration

## 🛠️ Technology Stack

- **Backend:** Node.js, Express.js
- **Database:** MongoDB Atlas
- **Authentication:** JWT (JSON Web Tokens)
- **Documentation:** Swagger/OpenAPI
- **Security:** bcryptjs for password hashing

## 📋 API Endpoints

### Authentication
- `POST /auth/register` - Create new user account
- `POST /auth/login` - Login user and get JWT token

### User Profile
- `GET /users/me` - Get current user profile
- `PUT /users/me` - Update user profile
- `POST /users/me/change-password` - Change password

### Todos
- `POST /todos` - Create new todo
- `GET /todos` - Get user's todos
- `GET /todos/{id}` - Get specific todo
- `PUT /todos/{id}` - Update todo
- `DELETE /todos/{id}` - Delete todo

### Admin
- `GET /admin/todos` - Get all todos from all users
- `DELETE /admin/todos/{id}` - Delete any todo
- `GET /admin/users` - Get all users
- `DELETE /admin/users/{id}` - Delete any user

## 🏃‍♂️ Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB Atlas account (free)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/Aly4242/todo-list-rest-api.git
   cd todo-list-rest-api