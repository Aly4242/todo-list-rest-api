const User = require('../models/User');
const Todo = require('../models/Todo');

exports.getAllTodos = async (req, res) => {
    try {
        const todos = await Todo.find().populate('user', 'name email').sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: todos.length,
            todos
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching todos',
            error: error.message
        });
    }
};

exports.deleteAnyTodo = async (req, res) => {
    try {
        const todo = await Todo.findById(req.params.id);

        if (!todo) {
            return res.status(404).json({
                success: false,
                message: 'Todo not found'
            });
        }

        await Todo.findByIdAndDelete(req.params.id);

        res.status(200).json({
            success: true,
            message: 'Todo deleted successfully by admin'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting todo',
            error: error.message
        });
    }
};

exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.find().select('-password').sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: users.length,
            users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching users',
            error: error.message
        });
    }
};

exports.deleteAnyUser = async (req, res) => {
    try {
        // FIX: Use req.user._id instead of req.user.id
        const currentUserId = req.user._id || req.user.id;
        
        // Prevent admin from deleting themselves
        if (req.params.id === currentUserId.toString()) {
            return res.status(400).json({
                success: false,
                message: 'Admin cannot delete their own account'
            });
        }

        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Delete user's todos first
        await Todo.deleteMany({ user: req.params.id });
        
        // Then delete user
        await User.findByIdAndDelete(req.params.id);

        res.status(200).json({
            success: true,
            message: 'User and their todos deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting user',
            error: error.message
        });
    }
};